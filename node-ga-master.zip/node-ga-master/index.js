module.exports = require('./lib/ga');
